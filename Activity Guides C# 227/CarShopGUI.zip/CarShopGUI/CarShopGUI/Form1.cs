﻿using CarShopConsoleApp;
using CarStoreActivity1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarShopGUI
{
    public partial class Form1 : Form
    {
        Store theStore = new Store();
        // Associate classe like a store with a control

        BindingSource carInventoryBindingSource = new BindingSource();
        BindingSource cartBindingSource = new BindingSource();
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_create_Click(object sender, EventArgs e)
        {
            Car c = new Car(txt_make.Text, txt_model.Text, decimal.Parse(txt_price.Text),txt_color.Text, txt_year.Text);

            // MessageBox.Show(c.ToString());
            theStore.CarsList.Add(c);
            carInventoryBindingSource.ResetBindings(false);

            txt_make.Text = "";
            txt_model.Text = "";
          





            cleartext();
            // Make sure you check so if you click a price as a sring it doesnt crash
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            carInventoryBindingSource.DataSource = theStore.CarsList;
            cartBindingSource.DataSource = theStore.ShoppingList;

            lst_inventory.DataSource = carInventoryBindingSource;
            lst_inventory.DisplayMember = ToString();


            lst_cart.DataSource = cartBindingSource;
            lst_cart.DisplayMember = ToString();




      
        }

        public void cleartext()
        {
            txt_make.Clear();
            txt_model.Clear();
            txt_color.Clear();
            txt_year.Clear();
            txt_price.Clear();

        }

        private void btn_addtocart_Click(object sender, EventArgs e)
        {
            // Get the selected item from inventory

            Car selected = (Car)lst_inventory.SelectedItem;

            // add that item to the cart
            theStore.ShoppingList.Add(selected);


            // UPdate the list box control
            cartBindingSource.ResetBindings(false);

         
        }

        private void btn_checkout_Click(object sender, EventArgs e)
        {
            decimal total = theStore.Checkout();
            lbl_total.Text = "$" + total.ToString();


            cartBindingSource.ResetBindings(false);
            
        }

      

    }
}
