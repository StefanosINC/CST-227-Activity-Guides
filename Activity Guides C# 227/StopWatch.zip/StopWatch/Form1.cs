﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StopWatch
{
    public partial class Form1 : Form
    {
        private static Stopwatch watch = new Stopwatch();
        private Random rng = new Random();


        private int timerInterval = 1000;
        private int hits = 0;
        private int count;
        private DateTime start;
        bool targetchoice = false;
        private int increasespeed = 900;
        public Form1()
        {
            InitializeComponent();
            timer1.Interval = timerInterval;
            
        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            BackgroundImage.Tag = Color.Black;
            watch.Start();

        }

        private void btn_stop_Click(object sender, EventArgs e)
        {

            watch.Stop();
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            watch.Reset();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            label1.Text = watch.Elapsed.ToString();
            btn_target.Top = rng.Next(0, this.Height);
            btn_target.Left = rng.Next(0, this.Width);
            btn_DontClick.Top = rng.Next(0, this.Height);
            btn_DontClick.Left = rng.Next(0, this.Width);

        }

        private void btn_target_Click(object sender, EventArgs e)
        {
           

            hits++;
            label2.Text = hits.ToString();
            int answer;
            answer = timerInterval - increasespeed;

            timerInterval = answer;


           

            // For some reason the game is actually ending at 6
            // Win function
            if(hits > 5)
            {
                MessageBox.Show("Aye man you win. Congrats. Here are the stats");
                MessageBox.Show(hits.ToString());
                MessageBox.Show(watch.Elapsed.ToString());
            }
            if(hits > 3)
            {
                int bonus = timer1.Interval + 300;
                bonus = timerInterval;

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_DontClick_Click(object sender, EventArgs e)
        {

            MessageBox.Show("WHOA WHOA you failed I have to remove 2 points from u");
            if (targetchoice)
            {
               
            }


            watch.Stop();
            MessageBox.Show(hits.ToString());
            MessageBox.Show(watch.Elapsed.ToString());
            this.Close();

        }
        private void Control1_MouseClick(Object sender, MouseEventArgs e)
        {

            switch (MouseButtons)
            {
                case MouseButtons.Left:
                    MessageBox.Show(" WHOAAAAA you clicked the form!!!!! Games gotta end now Here are your Stats");
                    MessageBox.Show(hits.ToString());
                    MessageBox.Show(watch.Elapsed.ToString());

                    break;

                case MouseButtons.Right:
                    MessageBox.Show("WHOAAAAA you clicked the form!!!!! Games gotta end now Here are your Stats");
                    MessageBox.Show(hits.ToString());
                    MessageBox.Show(watch.Elapsed.ToString());
                   
                    //this.Close();
                    break;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lbl_highScore_Click(object sender, EventArgs e)
        {

        }
    }
}
