﻿namespace StopWatch
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.btn_start = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btn_target = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_DontClick = new System.Windows.Forms.Button();
            this.lbl_highScore = new System.Windows.Forms.Label();
            this.btn_stop = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(40, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Time";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_start
            // 
            this.btn_start.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_start.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_start.BackgroundImage")));
            this.btn_start.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_start.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_start.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_start.Location = new System.Drawing.Point(12, 530);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(119, 117);
            this.btn_start.TabIndex = 1;
            this.btn_start.Text = "Start";
            this.btn_start.UseVisualStyleBackColor = false;
            this.btn_start.BackgroundImageChanged += new System.EventHandler(this.btn_start_Click);
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            this.btn_start.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Control1_MouseClick);
            this.btn_start.MouseCaptureChanged += new System.EventHandler(this.Form1_Load);
            // 
            // btn_reset
            // 
            this.btn_reset.BackColor = System.Drawing.SystemColors.MenuText;
            this.btn_reset.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_reset.BackgroundImage")));
            this.btn_reset.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_reset.Location = new System.Drawing.Point(342, 530);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(195, 147);
            this.btn_reset.TabIndex = 3;
            this.btn_reset.UseVisualStyleBackColor = false;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btn_target
            // 
            this.btn_target.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_target.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_target.BackgroundImage")));
            this.btn_target.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_target.ForeColor = System.Drawing.Color.Red;
            this.btn_target.Location = new System.Drawing.Point(581, 85);
            this.btn_target.Name = "btn_target";
            this.btn_target.Size = new System.Drawing.Size(108, 93);
            this.btn_target.TabIndex = 4;
            this.btn_target.Text = "Target";
            this.btn_target.UseVisualStyleBackColor = false;
            this.btn_target.Click += new System.EventHandler(this.btn_target_Click);
            this.btn_target.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Control1_MouseClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(40, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Score";
            // 
            // btn_DontClick
            // 
            this.btn_DontClick.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_DontClick.BackgroundImage")));
            this.btn_DontClick.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_DontClick.Location = new System.Drawing.Point(352, 85);
            this.btn_DontClick.Name = "btn_DontClick";
            this.btn_DontClick.Size = new System.Drawing.Size(173, 75);
            this.btn_DontClick.TabIndex = 6;
            this.btn_DontClick.Text = "DontClickMe!";
            this.btn_DontClick.UseVisualStyleBackColor = true;
            this.btn_DontClick.Click += new System.EventHandler(this.btn_DontClick_Click);
            // 
            // lbl_highScore
            // 
            this.lbl_highScore.AutoSize = true;
            this.lbl_highScore.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbl_highScore.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_highScore.Location = new System.Drawing.Point(40, 236);
            this.lbl_highScore.Name = "lbl_highScore";
            this.lbl_highScore.Size = new System.Drawing.Size(104, 25);
            this.lbl_highScore.TabIndex = 7;
            this.lbl_highScore.Text = "High Score";
            this.lbl_highScore.Click += new System.EventHandler(this.lbl_highScore_Click);
            // 
            // btn_stop
            // 
            this.btn_stop.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_stop.BackgroundImage")));
            this.btn_stop.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_stop.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.btn_stop.Location = new System.Drawing.Point(154, 530);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(182, 121);
            this.btn_stop.TabIndex = 2;
            this.btn_stop.UseVisualStyleBackColor = true;
            this.btn_stop.Click += new System.EventHandler(this.btn_stop_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1096, 678);
            this.Controls.Add(this.lbl_highScore);
            this.Controls.Add(this.btn_DontClick);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_target);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_stop);
            this.Controls.Add(this.btn_start);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Control1_MouseClick);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Control1_MouseClick);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btn_target;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_DontClick;
        private System.Windows.Forms.Label lbl_highScore;
        private System.Windows.Forms.Button btn_stop;
    }
}

