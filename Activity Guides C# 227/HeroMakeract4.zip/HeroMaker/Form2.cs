﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HeroMaker
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            BindingSource binding = new BindingSource();
            binding.DataSource = SuperHeroList.hallOfFame;
            listBox1.DataSource = binding;
            listBox1.DisplayMember = "Name";
        }
    }
}
