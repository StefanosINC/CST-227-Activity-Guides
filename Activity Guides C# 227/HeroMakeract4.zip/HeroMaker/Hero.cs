﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeroMaker
{
    public class Hero
    {
        public Hero(string name, bool[] specialAbilities, List<string> officeLocations, string preferredTransport, int speed, int stamina, int strength, DateTime birthday, DateTime superPOwerDiscoveryRate, DateTime fatefulDay, decimal yearsExperience, string capeColor, int darkSidePropensity, string portraitPhoto)
        {
            this.name = name;
            SpecialAbilities = specialAbilities;
            OfficeLocations = officeLocations;
            PreferredTransport = preferredTransport;
            Speed = speed;
            Stamina = stamina;
            Strength = strength;
            Birthday = birthday;
            SuperPOwerDiscoveryRate = superPOwerDiscoveryRate;
            FatefulDay = fatefulDay;
            YearsExperience = yearsExperience;
            CapeColor = capeColor;
            DarkSidePropensity = darkSidePropensity;
            PortraitPhoto = portraitPhoto;
        }

        public String name { get; set; }
        public bool[] SpecialAbilities { get; set; }
        public List<String> OfficeLocations { get; set; }
        public string PreferredTransport { get; set; }
        public int Speed { get; set; }
        public int Stamina { get; set; }
        public int Strength { get; set; }
        public DateTime Birthday { get; set; }
        public DateTime SuperPOwerDiscoveryRate { get; set; }
        public DateTime FatefulDay { get; set; }
        public decimal YearsExperience { get; set; }
        public String CapeColor { get; set; }
        public int DarkSidePropensity { get; set; }
        public String PortraitPhoto { get; set; }
        
    }
}
