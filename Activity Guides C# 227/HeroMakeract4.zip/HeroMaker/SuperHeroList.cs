﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeroMaker
{
    // static means that there will only be one copy ofthe list in this 
  static  public class SuperHeroList
    {
        static public List<Hero> hallOfFame = new List<Hero>();
    }
}
