﻿namespace HeroMaker
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chk_TimerControl = new System.Windows.Forms.CheckBox();
            this.chk_WaterBreathing = new System.Windows.Forms.CheckBox();
            this.chk_ExplosivePunch = new System.Windows.Forms.CheckBox();
            this.chk_ExtremeLuck = new System.Windows.Forms.CheckBox();
            this.chk_AbsorbEnergy = new System.Windows.Forms.CheckBox();
            this.chk_Invisibility = new System.Windows.Forms.CheckBox();
            this.chk_xrayVision = new System.Windows.Forms.CheckBox();
            this.chk_fly = new System.Windows.Forms.CheckBox();
            this.btn_create = new System.Windows.Forms.Button();
            this.lst_cities = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.rdo_JetPack = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdo_BatMobile = new System.Windows.Forms.RadioButton();
            this.rdo_Teleport = new System.Windows.Forms.RadioButton();
            this.rdo_LandSpeeder = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lbl_Strength = new System.Windows.Forms.Label();
            this.lbl_Stamina = new System.Windows.Forms.Label();
            this.lbl_Speed = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.scroll_Strength = new System.Windows.Forms.HScrollBar();
            this.scroll_Stamina = new System.Windows.Forms.HScrollBar();
            this.scroll_speed = new System.Windows.Forms.HScrollBar();
            this.track_dark = new System.Windows.Forms.TrackBar();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.date_birthday = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.date_powerDiscovery = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.date_fate = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.num_years_experience = new System.Windows.Forms.NumericUpDown();
            this.pic_cape_color = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lbl_dark_side = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.track_dark)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_years_experience)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_cape_color)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hero\'s Name";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(87, 9);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(188, 20);
            this.txtName.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chk_TimerControl);
            this.groupBox1.Controls.Add(this.chk_WaterBreathing);
            this.groupBox1.Controls.Add(this.chk_ExplosivePunch);
            this.groupBox1.Controls.Add(this.chk_ExtremeLuck);
            this.groupBox1.Controls.Add(this.chk_AbsorbEnergy);
            this.groupBox1.Controls.Add(this.chk_Invisibility);
            this.groupBox1.Controls.Add(this.chk_xrayVision);
            this.groupBox1.Controls.Add(this.chk_fly);
            this.groupBox1.Location = new System.Drawing.Point(12, 35);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(289, 206);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Special Abilities";
            // 
            // chk_TimerControl
            // 
            this.chk_TimerControl.AutoSize = true;
            this.chk_TimerControl.Location = new System.Drawing.Point(107, 144);
            this.chk_TimerControl.Name = "chk_TimerControl";
            this.chk_TimerControl.Size = new System.Drawing.Size(88, 17);
            this.chk_TimerControl.TabIndex = 8;
            this.chk_TimerControl.Text = "Timer Control";
            this.chk_TimerControl.UseVisualStyleBackColor = true;
            this.chk_TimerControl.CheckedChanged += new System.EventHandler(this.chk_TimerControl_CheckedChanged);
            // 
            // chk_WaterBreathing
            // 
            this.chk_WaterBreathing.AutoSize = true;
            this.chk_WaterBreathing.Location = new System.Drawing.Point(107, 107);
            this.chk_WaterBreathing.Name = "chk_WaterBreathing";
            this.chk_WaterBreathing.Size = new System.Drawing.Size(103, 17);
            this.chk_WaterBreathing.TabIndex = 7;
            this.chk_WaterBreathing.Text = "Water Breathing";
            this.chk_WaterBreathing.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chk_WaterBreathing.UseVisualStyleBackColor = true;
            // 
            // chk_ExplosivePunch
            // 
            this.chk_ExplosivePunch.AutoSize = true;
            this.chk_ExplosivePunch.Location = new System.Drawing.Point(107, 73);
            this.chk_ExplosivePunch.Name = "chk_ExplosivePunch";
            this.chk_ExplosivePunch.Size = new System.Drawing.Size(105, 17);
            this.chk_ExplosivePunch.TabIndex = 6;
            this.chk_ExplosivePunch.Text = "Explosive Punch";
            this.chk_ExplosivePunch.UseVisualStyleBackColor = true;
            // 
            // chk_ExtremeLuck
            // 
            this.chk_ExtremeLuck.AutoSize = true;
            this.chk_ExtremeLuck.Location = new System.Drawing.Point(107, 38);
            this.chk_ExtremeLuck.Name = "chk_ExtremeLuck";
            this.chk_ExtremeLuck.Size = new System.Drawing.Size(91, 17);
            this.chk_ExtremeLuck.TabIndex = 5;
            this.chk_ExtremeLuck.Text = "Extreme Luck";
            this.chk_ExtremeLuck.UseVisualStyleBackColor = true;
            // 
            // chk_AbsorbEnergy
            // 
            this.chk_AbsorbEnergy.AutoSize = true;
            this.chk_AbsorbEnergy.Location = new System.Drawing.Point(6, 144);
            this.chk_AbsorbEnergy.Name = "chk_AbsorbEnergy";
            this.chk_AbsorbEnergy.Size = new System.Drawing.Size(95, 17);
            this.chk_AbsorbEnergy.TabIndex = 4;
            this.chk_AbsorbEnergy.Text = "Absorb Energy";
            this.chk_AbsorbEnergy.UseVisualStyleBackColor = true;
            // 
            // chk_Invisibility
            // 
            this.chk_Invisibility.AutoSize = true;
            this.chk_Invisibility.Location = new System.Drawing.Point(6, 107);
            this.chk_Invisibility.Name = "chk_Invisibility";
            this.chk_Invisibility.Size = new System.Drawing.Size(70, 17);
            this.chk_Invisibility.TabIndex = 3;
            this.chk_Invisibility.Text = "Invisibility";
            this.chk_Invisibility.UseVisualStyleBackColor = true;
            // 
            // chk_xrayVision
            // 
            this.chk_xrayVision.AutoSize = true;
            this.chk_xrayVision.Location = new System.Drawing.Point(6, 73);
            this.chk_xrayVision.Name = "chk_xrayVision";
            this.chk_xrayVision.Size = new System.Drawing.Size(81, 17);
            this.chk_xrayVision.TabIndex = 2;
            this.chk_xrayVision.Text = "xRay Vision";
            this.chk_xrayVision.UseVisualStyleBackColor = true;
            // 
            // chk_fly
            // 
            this.chk_fly.AutoSize = true;
            this.chk_fly.Location = new System.Drawing.Point(6, 38);
            this.chk_fly.Name = "chk_fly";
            this.chk_fly.Size = new System.Drawing.Size(36, 17);
            this.chk_fly.TabIndex = 0;
            this.chk_fly.Text = "fly";
            this.chk_fly.UseVisualStyleBackColor = true;
            // 
            // btn_create
            // 
            this.btn_create.Location = new System.Drawing.Point(891, 639);
            this.btn_create.Name = "btn_create";
            this.btn_create.Size = new System.Drawing.Size(75, 23);
            this.btn_create.TabIndex = 3;
            this.btn_create.Text = "Create Hero";
            this.btn_create.UseVisualStyleBackColor = true;
            this.btn_create.Click += new System.EventHandler(this.btn_create_Click);
            // 
            // lst_cities
            // 
            this.lst_cities.FormattingEnabled = true;
            this.lst_cities.Items.AddRange(new object[] {
            "Moscow ",
            "New York",
            "London",
            "Paris",
            "Tokyo",
            "Hong Kong",
            "Rome",
            "Sydney"});
            this.lst_cities.Location = new System.Drawing.Point(12, 283);
            this.lst_cities.Name = "lst_cities";
            this.lst_cities.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lst_cities.Size = new System.Drawing.Size(120, 95);
            this.lst_cities.TabIndex = 4;
            this.lst_cities.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 254);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Office Locations";
            // 
            // rdo_JetPack
            // 
            this.rdo_JetPack.AutoSize = true;
            this.rdo_JetPack.Checked = true;
            this.rdo_JetPack.Location = new System.Drawing.Point(0, 19);
            this.rdo_JetPack.Name = "rdo_JetPack";
            this.rdo_JetPack.Size = new System.Drawing.Size(64, 17);
            this.rdo_JetPack.TabIndex = 6;
            this.rdo_JetPack.TabStop = true;
            this.rdo_JetPack.Text = "JetPack";
            this.rdo_JetPack.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdo_BatMobile);
            this.groupBox2.Controls.Add(this.rdo_Teleport);
            this.groupBox2.Controls.Add(this.rdo_LandSpeeder);
            this.groupBox2.Controls.Add(this.rdo_JetPack);
            this.groupBox2.Location = new System.Drawing.Point(147, 270);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(211, 118);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Preferred Transport";
            // 
            // rdo_BatMobile
            // 
            this.rdo_BatMobile.AutoSize = true;
            this.rdo_BatMobile.Location = new System.Drawing.Point(0, 95);
            this.rdo_BatMobile.Name = "rdo_BatMobile";
            this.rdo_BatMobile.Size = new System.Drawing.Size(72, 17);
            this.rdo_BatMobile.TabIndex = 9;
            this.rdo_BatMobile.Text = "BatMobile";
            this.rdo_BatMobile.UseVisualStyleBackColor = true;
            // 
            // rdo_Teleport
            // 
            this.rdo_Teleport.AutoSize = true;
            this.rdo_Teleport.Location = new System.Drawing.Point(0, 67);
            this.rdo_Teleport.Name = "rdo_Teleport";
            this.rdo_Teleport.Size = new System.Drawing.Size(64, 17);
            this.rdo_Teleport.TabIndex = 8;
            this.rdo_Teleport.Text = "Teleport";
            this.rdo_Teleport.UseVisualStyleBackColor = true;
            // 
            // rdo_LandSpeeder
            // 
            this.rdo_LandSpeeder.AutoSize = true;
            this.rdo_LandSpeeder.Location = new System.Drawing.Point(0, 43);
            this.rdo_LandSpeeder.Name = "rdo_LandSpeeder";
            this.rdo_LandSpeeder.Size = new System.Drawing.Size(89, 17);
            this.rdo_LandSpeeder.TabIndex = 7;
            this.rdo_LandSpeeder.Text = "LandSpeeder";
            this.rdo_LandSpeeder.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lbl_Strength);
            this.groupBox3.Controls.Add(this.lbl_Stamina);
            this.groupBox3.Controls.Add(this.lbl_Speed);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.scroll_Strength);
            this.groupBox3.Controls.Add(this.scroll_Stamina);
            this.groupBox3.Controls.Add(this.scroll_speed);
            this.groupBox3.Location = new System.Drawing.Point(23, 412);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(375, 165);
            this.groupBox3.TabIndex = 8;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Stamina Strength and Speed";
            // 
            // lbl_Strength
            // 
            this.lbl_Strength.AutoSize = true;
            this.lbl_Strength.Location = new System.Drawing.Point(80, 108);
            this.lbl_Strength.Name = "lbl_Strength";
            this.lbl_Strength.Size = new System.Drawing.Size(13, 13);
            this.lbl_Strength.TabIndex = 8;
            this.lbl_Strength.Text = "0";
            // 
            // lbl_Stamina
            // 
            this.lbl_Stamina.AutoSize = true;
            this.lbl_Stamina.Location = new System.Drawing.Point(80, 60);
            this.lbl_Stamina.Name = "lbl_Stamina";
            this.lbl_Stamina.Size = new System.Drawing.Size(13, 13);
            this.lbl_Stamina.TabIndex = 7;
            this.lbl_Stamina.Text = "0";
            // 
            // lbl_Speed
            // 
            this.lbl_Speed.AutoSize = true;
            this.lbl_Speed.Location = new System.Drawing.Point(80, 16);
            this.lbl_Speed.Name = "lbl_Speed";
            this.lbl_Speed.Size = new System.Drawing.Size(13, 13);
            this.lbl_Speed.TabIndex = 6;
            this.lbl_Speed.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Strength";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Stamina";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Speed";
            // 
            // scroll_Strength
            // 
            this.scroll_Strength.Location = new System.Drawing.Point(23, 121);
            this.scroll_Strength.Name = "scroll_Strength";
            this.scroll_Strength.Size = new System.Drawing.Size(321, 15);
            this.scroll_Strength.TabIndex = 2;
            this.scroll_Strength.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scroll_Strength_Scroll);
            // 
            // scroll_Stamina
            // 
            this.scroll_Stamina.Location = new System.Drawing.Point(23, 73);
            this.scroll_Stamina.Name = "scroll_Stamina";
            this.scroll_Stamina.Size = new System.Drawing.Size(321, 15);
            this.scroll_Stamina.TabIndex = 1;
            this.scroll_Stamina.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scroll_Stamina_Scroll);
            // 
            // scroll_speed
            // 
            this.scroll_speed.Location = new System.Drawing.Point(26, 32);
            this.scroll_speed.Name = "scroll_speed";
            this.scroll_speed.Size = new System.Drawing.Size(318, 15);
            this.scroll_speed.TabIndex = 0;
            this.scroll_speed.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scroll_speed_Scroll);
            // 
            // track_dark
            // 
            this.track_dark.LargeChange = 3;
            this.track_dark.Location = new System.Drawing.Point(527, 367);
            this.track_dark.Minimum = -10;
            this.track_dark.Name = "track_dark";
            this.track_dark.Size = new System.Drawing.Size(117, 45);
            this.track_dark.TabIndex = 1;
            this.track_dark.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.date_fate);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.date_powerDiscovery);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.date_birthday);
            this.groupBox4.Location = new System.Drawing.Point(343, 25);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(239, 171);
            this.groupBox4.TabIndex = 9;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "groupBox4";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // date_birthday
            // 
            this.date_birthday.Location = new System.Drawing.Point(6, 43);
            this.date_birthday.Name = "date_birthday";
            this.date_birthday.Size = new System.Drawing.Size(206, 20);
            this.date_birthday.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Birthday";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 66);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(118, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "Super Power Discovery";
            // 
            // date_powerDiscovery
            // 
            this.date_powerDiscovery.Location = new System.Drawing.Point(9, 83);
            this.date_powerDiscovery.Name = "date_powerDiscovery";
            this.date_powerDiscovery.Size = new System.Drawing.Size(200, 20);
            this.date_powerDiscovery.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 106);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Fateful Day";
            // 
            // date_fate
            // 
            this.date_fate.Location = new System.Drawing.Point(9, 123);
            this.date_fate.Name = "date_fate";
            this.date_fate.Size = new System.Drawing.Size(200, 20);
            this.date_fate.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(435, 227);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 13);
            this.label9.TabIndex = 10;
            this.label9.Text = "Years of Experience";
            // 
            // num_years_experience
            // 
            this.num_years_experience.Location = new System.Drawing.Point(543, 225);
            this.num_years_experience.Name = "num_years_experience";
            this.num_years_experience.Size = new System.Drawing.Size(120, 20);
            this.num_years_experience.TabIndex = 11;
            // 
            // pic_cape_color
            // 
            this.pic_cape_color.BackColor = System.Drawing.Color.Red;
            this.pic_cape_color.Location = new System.Drawing.Point(438, 254);
            this.pic_cape_color.Name = "pic_cape_color";
            this.pic_cape_color.Size = new System.Drawing.Size(225, 76);
            this.pic_cape_color.TabIndex = 12;
            this.pic_cape_color.TabStop = false;
            this.pic_cape_color.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(373, 254);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 13);
            this.label10.TabIndex = 13;
            this.label10.Text = "Cape Color";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(415, 367);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 13);
            this.label11.TabIndex = 14;
            this.label11.Text = "Dark Side Property";
            // 
            // lbl_dark_side
            // 
            this.lbl_dark_side.AutoSize = true;
            this.lbl_dark_side.Location = new System.Drawing.Point(418, 384);
            this.lbl_dark_side.Name = "lbl_dark_side";
            this.lbl_dark_side.Size = new System.Drawing.Size(0, 13);
            this.lbl_dark_side.TabIndex = 15;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.pictureBox1);
            this.groupBox5.Location = new System.Drawing.Point(444, 448);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(200, 100);
            this.groupBox5.TabIndex = 16;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Portrait";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(7, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(187, 70);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(978, 674);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.lbl_dark_side);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.pic_cape_color);
            this.Controls.Add(this.num_years_experience);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.track_dark);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lst_cities);
            this.Controls.Add(this.btn_create);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.track_dark)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_years_experience)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_cape_color)).EndInit();
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chk_TimerControl;
        private System.Windows.Forms.CheckBox chk_WaterBreathing;
        private System.Windows.Forms.CheckBox chk_ExplosivePunch;
        private System.Windows.Forms.CheckBox chk_ExtremeLuck;
        private System.Windows.Forms.CheckBox chk_AbsorbEnergy;
        private System.Windows.Forms.CheckBox chk_Invisibility;
        private System.Windows.Forms.CheckBox chk_xrayVision;
        private System.Windows.Forms.CheckBox chk_fly;
        private System.Windows.Forms.Button btn_create;
        private System.Windows.Forms.ListBox lst_cities;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rdo_JetPack;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rdo_BatMobile;
        private System.Windows.Forms.RadioButton rdo_Teleport;
        private System.Windows.Forms.RadioButton rdo_LandSpeeder;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lbl_Strength;
        private System.Windows.Forms.Label lbl_Stamina;
        private System.Windows.Forms.Label lbl_Speed;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.HScrollBar scroll_Strength;
        private System.Windows.Forms.HScrollBar scroll_Stamina;
        private System.Windows.Forms.HScrollBar scroll_speed;
        private System.Windows.Forms.TrackBar track_dark;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DateTimePicker date_fate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker date_powerDiscovery;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker date_birthday;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown num_years_experience;
        private System.Windows.Forms.PictureBox pic_cape_color;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lbl_dark_side;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

