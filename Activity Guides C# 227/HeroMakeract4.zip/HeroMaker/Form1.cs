﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HeroMaker
{
    public partial class Form1 : Form
    {
        // picture of hero
        string picture_of_hero = "";
        
        public Form1()
        {

            InitializeComponent();
        }



        private void btn_create_Click(object sender, EventArgs e)
        {
            string heroName = txtName.Text;
            // create a abilities array and set everything to false
            bool[] abilities = { false, false, false, false, false, false, false, false };

            abilities[0] = chk_fly.Checked;
            abilities[1] = chk_xrayVision.Checked;
            abilities[2] = chk_Invisibility.Checked;
            abilities[3] = chk_AbsorbEnergy.Checked;
            abilities[4] = chk_ExtremeLuck.Checked;
            abilities[5] = chk_ExplosivePunch.Checked;

            abilities[6] = chk_WaterBreathing.Checked;
            abilities[7] = chk_TimerControl.Checked;
            // List
            List<String> cities = new List<String>();
            // Add selected items to cities
            foreach (String s in lst_cities.SelectedItems)
            {
                cities.Add(s);
            }

            // preferred transport
            // use a single string since only one mode can be prefered transport
            string preferred_transport = "";

            if (rdo_JetPack.Checked)
                preferred_transport = "Jet Pack";
            if (rdo_LandSpeeder.Checked)
                preferred_transport = "LandSpeeder";

            if (rdo_Teleport.Checked)
                preferred_transport = "Teleport";

            if (rdo_BatMobile.Checked)
                preferred_transport = "BatMobile";



            string status_message = "\n Your new hero is " + txtName.Text + "You have selected the following abilities: ";

            if (abilities[0])
                status_message += "Fly, ";
            if (abilities[1])
                status_message += "xray Vision, ";
            if (abilities[2])
                status_message += "Invisibility, ";
            if (abilities[3])
                status_message += " Absorb Energy, ";
            if (abilities[4])
                status_message += " Extreme Luck, ";
            if (abilities[5])
                status_message += "Explosive Punches, ";
            if (abilities[6])
                status_message += "Water Breathing ";
            if (abilities[7])
                status_message += "Timer Control, ";

            // Dates 
            DateTime birthday = date_birthday.Value;

            DateTime superPowerDiscovery = date_powerDiscovery.Value;

            DateTime fatefulDay = date_fate.Value;

            decimal years_experience = num_years_experience.Value;
            // dark side
            int dark_side = 0;
            dark_side = track_dark.Value;

            // new control for abilities
            int speed = scroll_speed.Value;
            int stamina = scroll_Stamina.Value;
            int strength = scroll_Strength.Value;


            bool gamtest = true;
            
                if (speed + stamina + strength > 100)
                {
                    gamtest = false;
                    
             

                    MessageBox.Show("You cannot ahve more than 100 total points for strength, speed, and stamina");
                    

                }
            if (gamtest)
            {
                status_message += "\n The hero works in these cities: ";

                foreach (String city in cities)
                {
                    status_message += city + ",  ";
                }







                status_message += "\n your hero perfers to travel by:  " + preferred_transport;

                status_message += "\n Speed: " + speed + " strength: " + strength + "Stamina: " + stamina;

                status_message += "\nYour hero was born on " + birthday;
                status_message += "\n the Hero discovered super powers on " + superPowerDiscovery;
                status_message += "\nthe fateful day for this person is " + fatefulDay;

                status_message += "\n years of experience " + years_experience;


                status_message += "/n THe cape color for your hero is " + pic_cape_color.BackColor.ToString();
                status_message += "/n the dark side proability is " + dark_side;
                status_message += "/n the picture is " + picture_of_hero;


                Hero hero = new Hero(heroName, abilities, cities, preferred_transport, speed, stamina, strength, birthday, superPowerDiscovery, fatefulDay, years_experience, pic_cape_color.BackColor.ToString(), dark_side, picture_of_hero);

                SuperHeroList.hallOfFame.Add(hero);
              //  myHeroes.hallOfFame.Add(hero);

                MessageBox.Show(status_message);

                MessageBox.Show("You have made" + SuperHeroList.hallOfFame.Count() + " different heroes");

                Form2 f2 = new Form2();
                f2.Show();

            }

           
        }

        private void chk_TimerControl_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void scroll_speed_Scroll(object sender, ScrollEventArgs e)
        {
            lbl_Speed.Text = scroll_speed.Value.ToString();
        }

        private void scroll_Stamina_Scroll(object sender, ScrollEventArgs e)
        {
            lbl_Stamina.Text = scroll_Stamina.Value.ToString();

        }

        private void scroll_Strength_Scroll(object sender, ScrollEventArgs e)
        {
            lbl_Strength.Text = scroll_Strength.Value.ToString();
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            ColorDialog colorPicker = new ColorDialog();
            if(colorPicker.ShowDialog() == DialogResult.OK)
            {
                pic_cape_color.BackColor = colorPicker.Color;
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            lbl_dark_side.Text = track_dark.Value.ToString();
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog portraitPicker = new OpenFileDialog();
            if(portraitPicker.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = new Bitmap(portraitPicker.FileName);
                picture_of_hero = portraitPicker.FileName;
                
            }
        }
    }
}
    

