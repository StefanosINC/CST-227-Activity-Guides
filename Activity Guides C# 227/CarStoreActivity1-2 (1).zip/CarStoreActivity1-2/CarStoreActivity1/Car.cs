﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarStoreActivity1
{
   public class Car
    {

       public string Make { get; set; }
        public string Model { get; set; }
        public decimal Price { get; set; }
        
        public string Color { get; set; }
        public string Year { get; set; }

        // Default COnstructor it has no parameters
        public Car() { 
            Make = "nothing yet";
            Model = "nothing yet";
            Price = 0.00M;
            Color = "noColorooyet";
            Year = "noYear";
        }

        // Constructor with Paramters
        public Car(string a, string b, decimal c, string d, string e)
        {
            Make = a;
            Model = b;
            Price = c;
            Color = d;
            Year = e;
        }
        // TO STring This will print out new Car items.
       override public string ToString()
        {
            return "Make" + Make + " Model  " + Model + " Price $" + Price + "Color" + Color + "Year" + Year;
        }
    }
}
