﻿using CarStoreActivity1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarShopConsoleApp
{
    public class Store
    {

       
        public List<Car> CarsList { get; set; }
        public List<Car> ShoppingList { get; set; }

        // Constructor
        public Store()
        {
            CarsList = new List<Car>();
            ShoppingList = new List<Car>();



        }

        // Checkout Method
        public decimal Checkout()
        {
            decimal totalCost = 0;

            foreach (var c in ShoppingList)
            {
                totalCost = totalCost + c.Price;

            }
            ShoppingList.Clear();

            return totalCost;
        }
    }
}
