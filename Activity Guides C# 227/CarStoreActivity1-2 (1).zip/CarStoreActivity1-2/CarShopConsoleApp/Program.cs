﻿using CarStoreActivity1;
using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace CarShopConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {

            Store s = new Store();


            Console.WriteLine("Welcome to the Car Store. First you must create some car inventory Then you may add some cars to the Shopping cart. Finally you may checkout which will give you a total value of the shopping cart");


           int action = chooseAction();
            // While loop cloes unsell click 0 
            while (action != 0)
            {
                Console.WriteLine("you chose " + action);
              


                // Input the method for error

             // action = ErrorCheck();
                switch (action)
                {

                    // Add item to inventory
                    case 1:
                        Console.WriteLine("You choose to add a new car to the inventory");

                        // Define three values

                        String carMake = "";
                        String carModel = "";
                        Decimal carPrice = 0;
                        String carYear = "";
                        String carColor = "";

                        

                        Console.WriteLine("What is the car make? ford, gm, nissan etc. ");
                        carMake = Console.ReadLine();
                        

                        Console.WriteLine("What is the car model? corvette, focus , ranger etc.");
                        carModel = Console.ReadLine();

                        Console.WriteLine("What is the car price");
                        carPrice = CheckForErrors();

                        Console.WriteLine("What is the car year ?");
                        carYear = Console.ReadLine();

                        Console.WriteLine("What is the color of your car");
                        carColor = Console.ReadLine();



                        Car newCar = new Car(carMake, carModel, carPrice, carYear, carColor);

                        s.CarsList.Add(newCar);
                        printInventory(s);
                        break;


                    // add to cart
                    case 2:
                      Console.WriteLine("You choose to add a car to you shopping cart");
                        printInventory(s);
                        Console.WriteLine("which item would you like to buy? (number)");
                        int carChosen = int.Parse(Console.ReadLine());

                        s.ShoppingList.Add(s.CarsList[carChosen]);
                        printShoppingCart(s);
                      break;

                    case 3:
                        printShoppingCart(s);
                        Console.WriteLine("the total cost of your items is : " + s.Checkout());
                        




                        break;

                    case 4: 
               
                    default:
                        break;
                }

                


               action = chooseAction();

            }


        }

        private static void printShoppingCart(Store s)
        {
            Console.WriteLine("Cars you have chosen to buy ");
            for (int i = 0; i < s.ShoppingList.Count; i++)
            {


                Console.WriteLine("Car: #  " + i + " " + s.ShoppingList[i]);
            }
        }

        private static void printInventory(Store s)
        {
           for(int i = 0; i< s.CarsList.Count; i++)
            {

            
                Console.WriteLine("Car: #  " + i + " " + s.CarsList[i]);
            }
        }

        static public int chooseAction()
        {
            int choice = 0;
            Console.WriteLine("Choose an action (0) to quit (1) to add a new car to inventory (2) add car to cart (3) checkout");

            choice = int.Parse(Console.ReadLine());
            return choice;

        }
      // Search for errors to force an integer

        public static int CheckForErrors()
        {
            Boolean success = false;
            int userinput = -1;
            while (!success)
            {
                try
                {
                    userinput = Convert.ToInt32(Console.ReadLine());
                    success = true;
                }
                catch (FormatException)
                {
                    Console.WriteLine("You must enter an integer, not a string");
                }
            }
            return userinput;

        }

  

    }
    
}
